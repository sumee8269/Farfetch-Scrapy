import scrapy
from scrapy.crawler import CrawlerProcess
import json
import csv


class farfetch(scrapy.Spider):
    name = 'farfetch'
    base_url = 'https://www.farfetch.com/in/sets/women/new-in-this-week-eu-women.aspx?view=180&scale=275&category='


#run scraper
process = CrawlerProcess()
process.crawl(farfetch)
process.start()

# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.


def print_hi(name):
    # Use a breakpoint in the code line below to debug your script.
    print(f'Hi, {name}')  # Press Ctrl+F8 to toggle the breakpoint.


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    print_hi('PyCharm')

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
