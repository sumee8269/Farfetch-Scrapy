import pandas as pd
import pymongo

dic = pd.read_json('C:\\Users\\Sumit\\Desktop\\web scraper by scrapy\\farfetch\\items.json')

for i in range(0,400):
    product_name = dic["product_name"][i]
    product_brand = dic["product_brand"][i]
    product_price = dic["product_price"][i]
    product_imageUrl = dic["product_imageUrl"][i]
    product_productUrl = dic["product_productUrl"][i]
    product_category = dic["product_category"][i]
    for j in range(0,90):
        try:
            product_name_ = product_name[j]
            product_brand_ = product_brand[j]
            product_price_ = product_price[j]
            product_imageUrl_ = product_imageUrl[j]
            product_productUrl_ = product_productUrl[j]
            product_category_ = product_category
        except:
            product_name_ = "NONE"
            product_brand_ = "NONE"
            product_price_ = "NONE"
            product_imageUrl_ = "NONE"
            product_productUrl_ = "NONE"
            product_category_ = "NONE"

        record =dict(product_name=product_name_,product_brand=product_brand_,product_price=product_price_,product_imageUrl=product_imageUrl_,product_productUrl=product_productUrl_,product_category=product_category_)
        conn = pymongo.MongoClient("mongodb+srv://root:root@cluster1.zbwpk.mongodb.net/myFirstDatabase?retryWrites=true&w=majority")
        db = conn['FARFETCH']
        collection = db['farfetch_tb']
        collection.insert_one(record)