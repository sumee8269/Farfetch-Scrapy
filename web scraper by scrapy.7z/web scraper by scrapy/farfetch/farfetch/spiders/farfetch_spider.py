import scrapy
from ..items import FarfetchItem


class FarfetchSpiderSpider(scrapy.Spider):
    name = 'farfetch_spider'
    page_number = 1
    #start_urls = ['https://www.farfetch.com/de/shopping/men/shoes-2/items.aspx?page=1&view=180&scale=282>']
    start_urls = ['https://www.farfetch.com/fr/shopping/women/bags-purses-1/items.aspx?page=1&view=180&scale=282>']

    def parse(self, response):

        items = FarfetchItem() # this is the instance of the class FarfetchItem
        raw_image_urls = response.css('meta::attr(content)').extract()
        clean_image_urls = []
        clean_product_urls = []
        urls = response.css('a::attr(href)').extract()

        for url in urls:
            if 'storeid' in url:
                clean_product_urls.append(response.urljoin(url))

        for img_url in raw_image_urls:
            if len(img_url) == 78:
                clean_image_urls.append(response.urljoin(img_url))

        n = len(clean_image_urls)

        #field of items is defined in items.py file so that we can use here.
        product_name = response.xpath("//p[@itemprop ='name']/text()").extract()
        product_brand = response.xpath("//p[@class ='e17j0z620 css-14ahplz-Body-BodyBold-ProductCardBrandName eq12nrx0']/text()").extract()
        product_price = response.xpath("//p[@class ='css-hmsjre-Body-Price e15nyh750']/text()").extract()
        product_imageUrl = clean_image_urls[0:n:2]
        product_productUrl = clean_product_urls
        product_category = response.xpath("//h1[@class ='css-5zczy0-Display e1s5vycj0']/text()").extract()

        # Using our items
        items['product_name'] = product_name
        items['product_brand'] = product_brand
        items['product_price'] = product_price
        items['product_imageUrl'] = product_imageUrl
        items['product_productUrl'] = product_productUrl
        items['product_category'] = product_category

        yield items #It's like return, except the function will return a generator.

        # This will redirect to next page
        #next_page = 'https://www.farfetch.com/de/shopping/men/shoes-2/items.aspx?page='+str(FarfetchSpiderSpider.page_number)+'&view=180&scale=282'
        next_page = 'https://www.farfetch.com/fr/shopping/women/bags-purses-1/items.aspx?page='+str(FarfetchSpiderSpider.page_number)+'&view=180&scale=282'

        # Check the condition till 200 pages and increase the page_number by 1
        if FarfetchSpiderSpider.page_number < 200:
            FarfetchSpiderSpider.page_number += 1
            yield response.follow(next_page, callback= self.parse) # yielding and calling parse function